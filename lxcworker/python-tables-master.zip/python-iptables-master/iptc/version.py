# -*- coding: utf-8 -*-

__pkgname__ = "python-iptables"
__version__ = "0.5.0-dev"
